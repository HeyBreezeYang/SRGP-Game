安装Python2.7
设置Python环境变量

Windows系统：
1.打开excel_to_csv.bat文件
	用真实输入目录 替换 "输入目录"（比如："C:\\WZCQ\\策划\\配置文件"）
	用真实输出目录 替换 "输出目录"（比如："F:\\WZCQ\\策划\\输出文件"）
（注意：1.必须使用完整路径，2.必须使用双斜杠分割路径)
2.运行excel_to_csv.bat

Linux系统：
1.打开excel_to_csv.sh文件
	用真实输入目录 替换 "输入目录"（比如："/User/admin/WZCQ/策划/配置文件"）
	用真实输出目录 替换 "输出目录"（比如："/User/admin/WZCQ/策划/输出文件"）

（注意：1.必须使用完整路径)
2.终端执行： sh ./excel_to_csv.sh
